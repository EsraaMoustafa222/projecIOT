package com.example.car_fire_fighter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
